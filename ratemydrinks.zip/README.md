# ratemydrinks

Rate My Drinks! CS 546 Final Project

## Instructions

1. Download dependencies
```
npm install
```
2. Start the database service in another shell
```
mongod 
```

3. Run the seed to populate the database with pre-configured users, posts, beverages, and comments.
```
npm run seed
```

4. Run app.js to launch the service
```
npm start
```

3. Use the following login credentials
- **Username**: pbarresi
- **Password**: password

### A Helpful List of Seed Users and their Passwords
**Username**: mikeg67
- **Password**: imacoolguy

**Username**: proudmom1
- **Password**: lovemykids10

**Username**: justcynical12
- **Password**: imdeadinside

**Username**: snob13
- **Password**: highstandards

## Team Name
Phil Barresi is a Danger Noodle

### Team Members
- Calvin Han
- Vincent Lee
- Alex Schlumpf
- Sean Trinh
- Hariharan Vijayachandran

### Pledge
I pledge my honor that I have abided by the Stevens Honor System.
