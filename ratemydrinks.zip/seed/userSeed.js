module.exports = [
    {
        Email: "mikeg67@gmail.com",
        ScreenName: "mikeg67",
        Bio: "Just a really cool guy. Get at me.",
        password: "$2b$10$KwAXESQZOH/l3QdCJlCl0.6l/3WyayN1KKJfa0o5pDQ/kgzIkLcAO",
        Comments: []
    },
    {
        Email: "proudmom1@gmail.com",
        ScreenName: "proudmom1",
        Bio: "I really love my kids. They're so smart, athletic, and good-looking!",
        password: '$2b$10$r07CRYZwY0QH6E8bMaFSMueECn/7t6flS6/.cC1b3RBWLHvYFk2uC',
        Comments: []
    },
    {
        Email: "justcynical12@gmail.com",
        ScreenName: "justcynical12",
        Bio: "Everything is inferior to my intelligence.",
        password: '$2b$10$gHrkMy8KHA2yzgMIY8ydiOmyptcpP35pW7yg7zt/b0qeQVqNx9tYu',
        Comments: []
    },
    {
        Email: "snob13@gmail.com",
        ScreenName: "snob13",
        Bio: "I just can't stand things that don't meet my expectations. Some people just disgust me.",
        password: '$2b$10$p3kHzYPeQ3Gn.HiJxbWMZOoyS1S6tYqUo/MyxHMMLcK4K8SPykDSO',
        Comments: []
    },
    {
        Email: "pbarresi@stevens.edu",
        ScreenName: "pbarresi",
        Nio: "A wonderful professor for CS 546-WS.",
        password: '$2b$10$henc9Cmve0QNsT7X0wDwj.3aVv6otSdEtNcd2zYX5MDfUjQi7ilOC',
        Comments: []
    }
]