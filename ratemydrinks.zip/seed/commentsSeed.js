module.exports = [
    {
        user_id: "justcynical12",
        content: "What kind of sub-human are you? You are putting your son in danger by feeding him this garbage. Awful parenting."
    },
    {
        user_id: "proudmom1",
        content: "Please don't @ me, dear."
    },
    {
        user_id: "proudmom1",
        content: "What! The bottle looks just fine, dear. You shouldn't be picky over such things."
    },
    {
        user_id: "snob13",
        content: "Finally, a drink with good looking packaging. Central Jersey is so stylish, and I expected nothing less from this beer. Fantastic place. Go pork roll!"
    }
];